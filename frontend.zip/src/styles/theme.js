export default {
  containerWidth: '1300px',
};
