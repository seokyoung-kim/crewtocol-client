import React from 'react';
import styled from 'styled-components';
import colors from '../../styles/colors';
import Responsive from './Responsive';

const Wrapper = styled(Responsive)`
  max-width: ${(props) => props.theme.containerWidth};

  height: 300px;
  background-color: ${colors.gray[5]};
`;

const Banner = () => (
  <Wrapper>
    <></>
  </Wrapper>
);

export default Banner;
